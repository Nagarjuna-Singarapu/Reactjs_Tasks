// App.js
import React from 'react';
import EmployeeManagementSystem from './EmployeeManagementSystem';

function App() {
  return (
    <div className="App">
      <EmployeeManagementSystem />
    </div>
  );
}

export default App;
