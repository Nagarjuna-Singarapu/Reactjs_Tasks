// App.js
import React from 'react';
import Timer from './Timer';

const App = () => {
  return (
    <div>
      <Timer />
    </div>
  );
};

export default App;
